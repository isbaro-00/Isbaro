# Isbaro v3 — production-ready starter

## Stack
Node.js + Express + PostgreSQL + Socket.IO + JWT (httpOnly cookie for HTTP API).

## Local
1. Install Node.js 20+.
2. Create PostgreSQL database.
3. Run `db/schema.sql`.
4. Copy `.env.example` to `.env`.
5. Set DATABASE_URL and a long random JWT_SECRET.
6. `npm install`
7. `npm start`
8. Open http://localhost:3000

## Render deployment
The included `render.yaml` can create a Node web service and PostgreSQL database. Connect the repo to Render, review the blueprint, and set `CLIENT_ORIGIN` to the final HTTPS origin. Keep secrets in Render Environment Variables; never commit `.env`.

## Important
This is a backend foundation, not a complete public launch. Before opening to real users, add email verification/password reset, image storage (object storage), moderation/admin dashboard, rate limiting, abuse detection, privacy/terms pages, backups, logging/monitoring, and a production frontend wired to these APIs.
