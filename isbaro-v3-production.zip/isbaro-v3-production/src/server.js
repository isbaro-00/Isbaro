import 'dotenv/config';
import express from 'express';
import http from 'http';
import helmet from 'helmet';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import cookieParser from 'cookie-parser';
import pg from 'pg';
import { Server } from 'socket.io';
import path from 'path';
import { fileURLToPath } from 'url';

const {Pool}=pg;
const app=express(), server=http.createServer(app);
const PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET;
if(!JWT_SECRET) throw new Error('JWT_SECRET is required');
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.NODE_ENV==='production'?{rejectUnauthorized:false}:false});
const io=new Server(server,{cors:{origin:process.env.CLIENT_ORIGIN||false,credentials:true}});
app.use(helmet()); app.use(express.json({limit:'100kb'})); app.use(cookieParser());
app.use(express.static(path.join(path.dirname(fileURLToPath(import.meta.url)),'../public')));

function tokenFor(user){return jwt.sign({id:user.id},JWT_SECRET,{expiresIn:'7d'});}
function auth(req,res,next){try{const t=req.cookies.token||req.headers.authorization?.replace('Bearer ','');req.user=jwt.verify(t,JWT_SECRET);next()}catch{return res.status(401).json({error:'Unauthorized'})}}
function validId(x){return Number.isInteger(Number(x))&&Number(x)>0}

app.get('/api/health',async(req,res)=>{try{await pool.query('SELECT 1');res.json({ok:true})}catch{res.status(503).json({ok:false})}});
app.post('/api/auth/signup',async(req,res)=>{
 const {email,password,name,age,gender,bio='',city='',photo_url=''}=req.body;
 if(!email||!password||!name||!validId(age)||Number(age)<18||password.length<8)return res.status(400).json({error:'Invalid signup data'});
 try{const hash=await bcrypt.hash(password,12);const q=await pool.query('INSERT INTO users(email,password_hash,name,age,gender,bio,city,photo_url) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id,email,name,age,gender,bio,city,photo_url',[email.toLowerCase(),hash,name,age,gender,bio,city,photo_url]);const u=q.rows[0];res.cookie('token',tokenFor(u),{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',maxAge:604800000});res.status(201).json({user:u})}catch(e){res.status(e.code==='23505'?409:500).json({error:e.code==='23505'?'Email already exists':'Server error'})}
});
app.post('/api/auth/login',async(req,res)=>{const {email,password}=req.body;try{const q=await pool.query('SELECT * FROM users WHERE email=$1',[email?.toLowerCase()]);if(!q.rowCount||!(await bcrypt.compare(password,q.rows[0].password_hash)))return res.status(401).json({error:'Invalid credentials'});const u=q.rows[0];delete u.password_hash;res.cookie('token',tokenFor(u),{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',maxAge:604800000});res.json({user:u})}catch{res.status(500).json({error:'Server error'})}});
app.post('/api/auth/logout',(req,res)=>{res.clearCookie('token');res.json({ok:true})});
app.get('/api/me',auth,async(req,res)=>{const q=await pool.query('SELECT id,email,name,age,gender,bio,city,photo_url FROM users WHERE id=$1',[req.user.id]);res.json(q.rows[0])});

app.get('/api/discover',auth,async(req,res)=>{const {gender,minAge=18,maxAge=100,q=''}=req.query;const r=await pool.query(`SELECT id,name,age,gender,bio,city,photo_url FROM users WHERE id<>$1 AND age BETWEEN $2 AND $3 AND ($4='' OR gender=$4) AND (name ILIKE '%'||$5||'%' OR bio ILIKE '%'||$5||'%') AND id NOT IN (SELECT target_id FROM blocks WHERE user_id=$1) AND id NOT IN (SELECT user_id FROM blocks WHERE target_id=$1) ORDER BY created_at DESC LIMIT 50`,[req.user.id,minAge,maxAge,gender||'',q]);res.json(r.rows)});
app.post('/api/likes/:id',auth,async(req,res)=>{const id=Number(req.params.id);if(!validId(id)||id===req.user.id)return res.status(400).json({error:'Invalid target'});await pool.query('INSERT INTO likes(user_id,target_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.user.id,id]);const m=await pool.query('SELECT 1 FROM likes WHERE user_id=$1 AND target_id=$2',[id,req.user.id]);res.json({liked:true,match:!!m.rowCount})});
app.get('/api/matches',auth,async(req,res)=>{const r=await pool.query(`SELECT u.id,u.name,u.age,u.gender,u.bio,u.city,u.photo_url FROM users u JOIN likes l ON l.target_id=u.id WHERE l.user_id=$1 AND EXISTS(SELECT 1 FROM likes x WHERE x.user_id=u.id AND x.target_id=$1)`,[req.user.id]);res.json(r.rows)});
app.post('/api/block/:id',auth,async(req,res)=>{await pool.query('INSERT INTO blocks(user_id,target_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.user.id,Number(req.params.id)]);res.json({ok:true})});
app.post('/api/report/:id',auth,async(req,res)=>{const reason=String(req.body.reason||'No reason').slice(0,1000);await pool.query('INSERT INTO reports(reporter_id,target_id,reason) VALUES($1,$2,$3)',[req.user.id,Number(req.params.id),reason]);res.json({ok:true})});
app.get('/api/messages/:id',auth,async(req,res)=>{const id=Number(req.params.id);const r=await pool.query(`SELECT id,sender_id,receiver_id,body,created_at FROM messages WHERE (sender_id=$1 AND receiver_id=$2) OR (sender_id=$2 AND receiver_id=$1) ORDER BY created_at ASC LIMIT 200`,[req.user.id,id]);res.json(r.rows)});
app.post('/api/messages/:id',auth,async(req,res)=>{const id=Number(req.params.id),body=String(req.body.body||'').trim();if(!body||body.length>2000)return res.status(400).json({error:'Invalid message'});const r=await pool.query('INSERT INTO messages(sender_id,receiver_id,body) VALUES($1,$2,$3) RETURNING *',[req.user.id,id,body]);const msg=r.rows[0];io.to(`user:${id}`).emit('message',msg);res.status(201).json(msg)});

io.use((socket,next)=>{try{const t=socket.handshake.auth?.token;socket.user=jwt.verify(t,JWT_SECRET);next()}catch{next(new Error('Unauthorized'))}});
io.on('connection',socket=>{socket.join(`user:${socket.user.id}`);socket.on('send_message',async({to,body})=>{if(!validId(to)||!body||body.length>2000)return;const r=await pool.query('INSERT INTO messages(sender_id,receiver_id,body) VALUES($1,$2,$3) RETURNING *',[socket.user.id,to,String(body).trim()]);io.to(`user:${to}`).emit('message',r.rows[0]);socket.emit('message',r.rows[0])})});

server.listen(PORT,'0.0.0.0',()=>console.log(`Isbaro running on ${PORT}`));
